<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row col-12">
            <div class="col-10">
                <h2 class="text-xl font-semibold text-black ">Previous Purchases</h2>
            </div>
            <div class="col-2">
            <a href="<?php echo e(url('bill')); ?>" class="side-nav-animation ajaxload" title="billpage"><button type="button" class="btn btn-primary">Add Cart</button></a>
            
            </div>
        </div>
        <div class="col-12">
            <table class="table">
                <thead>
                    <tr>
                        <th class="width:20%;">#</th>
                        <th class="width:20%;">Invoice Number</th>
                        <th class="width:20%;">Date</th>
                        <th class="width:20%;">Total Amount</th>
                        <th class="width:20%;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $previousPurchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($purchase->id); ?></td>
                            <td><?php echo e($purchase->created_at); ?></td>
                            <td>$<?php echo e(number_format($purchase->total_amount, 2)); ?></td>
                            <td><a href="<?php echo e(route('Purchase.viewinvoice', $purchase->id)); ?>"><button type="button" class="btn btn-info">View Details</button></a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Bill_project\resources\views/welcome.blade.php ENDPATH**/ ?>