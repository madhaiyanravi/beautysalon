     
        
        

<?php $__env->startSection('content'); ?>

        <div class="row col-12">
                <h2 class="font-semibold text-black text-center">Invoice Info</h2>
        </div>
        <div class="row col-10">
                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                        <a href="<?php echo e(url('/')); ?>" class="side-nav-animation ajaxload" title="billpage"><button type="button" class="btn btn-primary text-black me-md-2">Home</button></a>
                    </div>
                </div>
        <div class="container text-center">
            <?php echo $htmlContent; ?>

        <div>
       
    
<script src="<?php echo e(asset('custom/js/custom.js')); ?>"></script> 

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Bill_project\resources\views/bill_report/viewbill.blade.php ENDPATH**/ ?>