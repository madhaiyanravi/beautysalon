     
        
        

<?php $__env->startSection('content'); ?>

        <div class="row col-12">
                <h2 class="font-semibold text-black text-center">Billing Page</h2>
        </div>
        <div class="container">
            <div class="row mt-4">
                <div class="mb-3 row">
                    <label for="staticEmail" class="col-sm-2 col-form-label">Email</label>
                    <div class="col-sm-8">
                    <input type="text" class="form-control" id="Email" placeholder="ABC@email.com">
                    </div>
                </div>
            </div>
            <div id="container">
                <div class="row col-10">
                    <div class="d-md-flex justify-content-md-end">
                        <button type="button" class="btn btn-success text-black add-row">Add Product</button>
                    </div>
                </div>
                <div class="row col-10 mt-2">
                    <div class="col-2"><b>Bill Section</b></div>
                    <div class="col-4">
                        <select class="form-control" name="Product[]" id="Product" >
                            <option value="">Select</option>
                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($ProductUID == $values->product_id): ?>
                                    <option value="<?php echo e($values->product_id); ?>" selected ><?php echo e($values->product_id); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($values->product_id); ?>"  ><?php echo e($values->product_id); ?></option>
                                <?php endif; ?>    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-4">
                        <input type="number" class="form-control" id="quantity" name="quantity[]" min="1">
                    </div>
                </div>
            </div>
        <div>
    
<script src="<?php echo e(asset('custom/js/custom.js')); ?>"></script> 

<?php $__env->stopSection(); ?>
<!-- <script>
$(document).ready(function () {
    $('#myTable').on('click', 'input[type="button"]', function () {
        $(this).closest('tr').remove();
    })
    $('.add_row').click(function () {
        $('#myTable').append('<tr><td><input type="text" class="fname" /></td><td><input type="button" value="Delete" /></td></tr>')
    });
});
</script> -->

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Miniproject\Bill_project\resources\views/bill_report/bill.blade.php ENDPATH**/ ?>