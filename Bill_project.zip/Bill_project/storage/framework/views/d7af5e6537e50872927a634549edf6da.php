<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="emailtemplate" content="width=device-width, initial-scale=1.0">
    <title>Billing App</title> 
    <style>
        table {
            width: 100%; /* Make the table occupy the full width */
        }
        td {
            padding-right: 10px; /* Add some padding between the values and colons */
        }
    </style>
</head>
<body>
        <div class="row col-12">
            <h2 class="font-semibold text-black text-center">Invoice Info</h2>
        </div>
        <div class="container text-center">
            <?php echo $details['htmlcontent']; ?>

        <div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Bill_project\resources\views/bill_report/emailtemplate.blade.php ENDPATH**/ ?>