
     
        
        @extends('layouts.app')

@section('content')

        <div class="row col-12">
                <h2 class="font-semibold text-black text-center">Billing Page</h2>
        </div>
        <form id="product_details">
            @csrf
            <div class="container text-center col-12">
                <div class="row mt-4 col-10">
                        <div class="col-2">
                            <label for="staticEmail" class="col-sm-2 col-form-label"><b>Email</b></label>
                        </div>
                        <div class="col-8">
                        <input type="text" class="form-control" id="Email" name="Email" placeholder="Ex:ABC@email.com">
                        </div>
                </div>
                <div id="container">
                    <div class="row col-10">
                        <div class="d-md-flex justify-content-md-end">
                            <button type="button" class="btn btn-success text-black add-row">Add Product</button>
                        </div>
                    </div>
                    <div class="row col-10 mt-2">
                        <div class="col-2"><b>Bill Section</b></div>
                        <div class="col-4">
                            <select class="form-control" name="Product[]" id="Product" >
                                <option value="">Select</option>
                                @foreach($product as $values)
                                    @if($ProductUID == $values->product_id)
                                        <option value="{{$values->product_id}}" selected >{{$values->name}}</option>
                                    @else
                                        <option value="{{$values->product_id}}"  >{{$values->name}}</option>
                                    @endif    
                                @endforeach
                            </select>
                        </div>
                        <div class="col-4">
                            <input type="number" class="form-control" id="quantity" name="quantity[]" min="1">
                        </div>
                    </div>
                </div>
                <div class="mt-4">
                    <div class="row col-10">
                        <div class="d-md-flex justify-content-md-start">
                            <b>Denominations</b>
                        </div>
                    </div>
                    <div class="row col-10 mt-5">
                        <div class="col-4 justify-content-md-center"><b>  500 *</b></div>
                        <div class="col-4 justify-content-md-center">
                            <input type="input" class="form-control" id="fivehundred" name="fivehundred" min="1">
                        </div>
                    </div>
                    <div class="row col-10 mt-2">
                        <div class="col-4 justify-content-md-center"><b>  50 *</b></div>
                        <div class="col-4 justify-content-md-center">
                            <input type="input" class="form-control" id="fifty" name="fifty" min="1">
                        </div>
                    </div>
                    <div class="row col-10 mt-2">
                        <div class="col-4 justify-content-md-center"><b>  20 *</b></div>
                        <div class="col-4 justify-content-md-center">
                            <input type="input" class="form-control" id="twenty" name="twenty" min="1">
                        </div>
                    </div>
                    <div class="row col-10 mt-2">
                        <div class="col-4 justify-content-md-center"><b>  10 *</b></div>
                        <div class="col-4 justify-content-md-center">
                            <input type="input" class="form-control" id="ten" name="ten" min="1">
                        </div>
                    </div>
                    <div class="row col-10 mt-2">
                        <div class="col-4 justify-content-md-center"><b>  5 *</b></div>
                        <div class="col-4 justify-content-md-center">
                            <input type="input" class="form-control" id="five" name="five" min="1">
                        </div>
                    </div>
                    <div class="row col-10 mt-2">
                        <div class="col-4 justify-content-md-center"><b>  2 *</b></div>
                        <div class="col-4 justify-content-md-center">
                            <input type="input" class="form-control" id="two" name="two">
                        </div>
                    </div>
                    <div class="row col-10 mt-2">
                        <div class="col-4 justify-content-md-center"><b>  1 *</b></div>
                        <div class="col-4 justify-content-md-center">
                            <input type="input" class="form-control" id="one" name="one">
                        </div>
                    </div>
                    <div class="row col-10 mt-2">
                        <div class="col-4 justify-content-md-center"><b>  Cash paid by customer</b></div>
                        <div class="col-4 justify-content-md-center">
                            <input type="input" class="form-control" id="cashamount" name="cashamount">
                        </div>
                    </div>
                </div>
                <div class="row col-10">
                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                        <a href="{{url('/')}}" class="side-nav-animation ajaxload" title="billpage"><button type="button" class="btn btn-danger text-black add-row me-md-2">Cancel</button></a>
                        <button type="button" class="btn btn-success text-black generate-bill">Generate Bill</button>
                    </div>
                </div>
            <div>
        </form>
    
<script src="{{asset('custom/js/custom.js')}}"></script> 

@endsection
