@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row col-12">
            <div class="col-10">
                <h2 class="text-xl font-semibold text-black ">Previous Purchases</h2>
            </div>
            <div class="col-2">
            <a href="{{url('bill')}}" class="side-nav-animation ajaxload" title="billpage"><button type="button" class="btn btn-primary">Add Cart</button></a>
            
            </div>
        </div>
        <div class="col-12">
            <table class="table">
                <thead>
                    <tr>
                        <th class="width:20%;">#</th>
                        <th class="width:20%;">Invoice Number</th>
                        <th class="width:20%;">Date</th>
                        <th class="width:20%;">Total Amount</th>
                        <th class="width:20%;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($previousPurchases as $index => $purchase)
                        <tr>
                            <td>{{ $index + 1 }}</td>
                            <td>{{ $purchase->id }}</td>
                            <td>{{ $purchase->created_at }}</td>
                            <td>${{ number_format($purchase->total_amount, 2) }}</td>
                            <td><a href="{{ route('Purchase.viewinvoice', $purchase->id) }}"><button type="button" class="btn btn-info">View Details</button></a></td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
