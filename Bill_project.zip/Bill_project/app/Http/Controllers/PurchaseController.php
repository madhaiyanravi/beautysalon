<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Products;
use App\Models\Purchaselist;
use App\Models\Orderdetails;
use App\Models\Denominations;
use App\Models\Itemdetails;
use Illuminate\Support\Facades\Mail;
use App\Mail\testmail;


class PurchaseController extends Controller
{
    public function index()
    {
        $data['previousPurchases'] = Purchaselist::select('id','created_at', 'total_amount', 'customer_email')
        ->orderBy('created_at', 'desc')
        ->get();
        return view('welcome',$data);
    }

    public function calculateBill()
    {
        $data['product'] = Products::select('product_id', 'name')
        ->orderBy('product_id', 'Asc')
        ->get();
        $data['ProductUID']= "";
        return view('bill_report.bill',$data);
    }

    public function getproductdata(){
        $data = Products::select('product_id', 'name')
        ->orderBy('product_id', 'Asc')
        ->get();
        $response_data = response()->json([
            'result' => $data,
            'status' => 1
        ]);
        return $response_data;
    }

    public function generatebilling(Request $request){
        $Email = $request->input('Email');
        $Product = $request->input('Product');
        $quantity = $request->input('quantity');
        $fivehundred = $request->input('fivehundred');
        $fifty = $request->input('fifty');
        $twenty = $request->input('twenty');
        $ten = $request->input('ten');
        $five = $request->input('five');
        $two = $request->input('two');
        $one = $request->input('one');
        $cashamount = $request->input('cashamount');
        $tax = Products::select('price','tax_percentage')->whereIn('product_id',$Product)->get();
        $itemlist = [];
        foreach ($Product as $key => $value) {
            $itemlist []= ['prodctid'=> $value,'quantity'=>$quantity[$key]];
        }

        if($Email != ""){
            $taxamount = 0;
            $totalprice = 0;
            foreach ($tax as $key => $value) {
                $taxamount+= ($value['price']* $quantity[$key] * $value['tax_percentage']) / 100;
                $totalprice+= $value['price']* $quantity[$key];
            }

            $purchase = new Purchaselist;
            $purchase->customer_email = $Email;
            $purchase->total_amount = $totalprice + $taxamount;
            $purchase->Paidamount = $cashamount;
            $purchase->tax_amount = $taxamount;
            $purchase->save();
            $id = $purchase->id;

            $denomination = new Denominations;
            $denomination->purchaseid= $id;
            $denomination->fivehundredcount= $fivehundred;
            $denomination->fiftycount= $fifty;
            $denomination->twentycount= $twenty;
            $denomination->tencount= $ten;
            $denomination->fivecount= $five;
            $denomination->twocount= $two;
            $denomination->onecount= $one;
            $denomination->save();

            foreach ($itemlist as $key => $value) {
                $price = Products::select('price','tax_percentage')->where('product_id',$value['prodctid'])->get();
                
                foreach ($price as $key => $val) {
                    $unitprice = $val['price'];
                    $taxpercentage = $val['tax_percentage'];
                    
                }
                $Orderdetails = new Itemdetails;
                $Orderdetails->purchaseid=$id;
                $Orderdetails->product_id=$value['prodctid'];
                $Orderdetails->unitprice=$unitprice;
                $Orderdetails->quantity=$value['quantity'];
                $Orderdetails->purchaseprice=$unitprice * $value['quantity'];
                $Orderdetails->taxpercentage=$taxpercentage;
                $Orderdetails->totalprice=($unitprice * $value['quantity'] * $taxpercentage) / 100;
                $Orderdetails->save();
            }
            
            $html= $this->htmlview($id);

            $details['htmlcontent']=$html;

            $email = $this->emailsend($details,$Email);

            $response_data = response()->json([
                'result' => $id,
                'status' => 1
            ]);
            return $response_data;
        }else{
            $response_data = response()->json([
                'result' => "EmailId Mandatory please fill !!",
                'status' => 0
            ]);
            return $response_data;
        }
    }



    public function viewinvoice($id)
    {
        $html= $this->htmlview($id);        
        return view('bill_report.viewbill')->with('htmlContent',$html);
    }

    public function htmlview($id){

        $previousPurchases = Purchaselist::leftjoin('Denominations','Purchaselist.id','=','Denominations.purchaseid')->select('Purchaselist.customer_email','Purchaselist.total_amount','Purchaselist.tax_amount','Purchaselist.Paidamount','Denominations.fivehundredcount','Denominations.fiftycount','Denominations.twentycount','Denominations.tencount','Denominations.fivecount','Denominations.twocount','Denominations.onecount')->where('Purchaselist.id',$id)->get();

        foreach ($previousPurchases as $key => $list) {

            $email = $list['customer_email'];
            $html = '<div class="row mt-4 col-10"><div class="col-2"><label for="staticEmail" class="col-sm-2 col-form-label"><b>Email</b></label></div><div class="col-8">              <b>'.$email.'</b></div></div><div class="col-12 mt-5"><table class="table"><thead><tr><th>ProductID</th><th>Unit Price</th><th>Quantity</th><th>Purchase Price</th><th>Tax %</th><th>Tax Payable amount</th><th>Total Iteam Price</th></tr></thead><tbody>';
            
            $itemlist = Itemdetails::select('*')->where('Purchaseid',$id)->orderBy('id','Asc')->get();

            foreach ($itemlist as $key => $product) {
                $taxpayable = ($product['unitprice']*$product['taxpercentage'])/100;
                $totalitemprice = $product['unitprice']*$product['quantity'];
                $html.='<tr><td>'.$product['product_id'].'</td><td>'.$product['unitprice'].'</td><td>'.$product['quantity'].'</td><td>'.$product['purchaseprice'].'</td><td>'.$product['taxpercentage'].'</td><td>'.$taxpayable.'</td><td>'.$totalitemprice.'</td></tr>';
            }

            $totalpurchaseamount = number_format($list['total_amount'] + $list['tax_amount'],2);
            $roundamount =round(intval($totalpurchaseamount)).'.00';
            $balanceamount = $list['Paidamount'] - $roundamount .'.00';

            $html.='</tbody></table></div><div class="mt-5" style="margin-left:70%"><table><tr><td><b>Total price without tax : </b></td><td>'.$list['total_amount'].'</td></tr><tr><td><b>Total tax payable :</b></td><td>'.$list['tax_amount'].'</td></tr><tr><td><b>Net price of the purchased item :</b></td><td>'.$totalpurchaseamount.'</td></tr><tr><td><b>Rounded value of the purchased items net price :</b></td><td>'.$roundamount.'</td></tr><tr><td><b>Balance payable to the customer :</b></td><td>'.$balanceamount.'</td></tr></table></div><hr style="border-top:4px solid #000">';

            $html.='<div class="mt-5 mb-5" style="margin-left:70%"><div class="mt-4"><div class="row col-10"><div class="d-md-flex justify-content-md-start"><b>Balance Denominations :</b></div></div><div class="row col-10 mt-5"><div class="col-4 justify-content-md-center"><b>500 :</b></div><div class="col-4 justify-content-md-center"><b>'.$list['fivehundredcount'].'</b></div></div><div class="row col-10 mt-2"><div class="col-4 justify-content-md-center"><b>50 :</b></div><div class="col-4 justify-content-md-center"><b>'.$list['fiftycount'].'</b></div></div><div class="row col-10 mt-2"><div class="col-4 justify-content-md-center"><b>20 :</b></div><div class="col-4 justify-content-md-center"><b>'.$list['twentycount'].'</b></div></div><div class="row col-10 mt-2"><div class="col-4 justify-content-md-center"><b>10 :</b></div><div class="col-4 justify-content-md-center"><b>'.$list['tencount'].'</b></div></div><div class="row col-10 mt-2"><div class="col-4 justify-content-md-center"><b>5 :</b></div><div class="col-4 justify-content-md-center"><b>'.$list['fivecount'].'</b></div></div><div class="row col-10 mt-2"><div class="col-4 justify-content-md-center"><b>2 :</b></div><div class="col-4 justify-content-md-center"><b>'.$list['twocount'].'</b></div></div><div class="row col-10 mt-2"><div class="col-4 justify-content-md-center"><b>1 :</b></div><div class="col-4 justify-content-md-center"><b>'.$list['onecount'].'</b></div></div></div></div>';

        }

        return $html;
    }

    public function emailsend($details,$Email){
        try {
             Mail::to($Email)->send(new testmail($details));
            return "Email sent successfully!";
        } catch (\Exception $e) {
            // Email sending failed
            return response()->json(['message' => 'Failed to send email', 'error' => $e->getMessage()], 500);
        }
    }

}
