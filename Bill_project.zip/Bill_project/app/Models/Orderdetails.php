<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;

class Orderdetails extends Model
{
    use HasFactory;

    protected $connection = 'mysql_select';

    protected $table = 'orderdetails';

    protected $primaryKey = 'TransactionUID';

    public $timestamps = false;

}