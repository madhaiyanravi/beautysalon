<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PurchaseController;

// Route::get('/', function () {
//     return view('welcome');
// });



Route::get('/',[PurchaseController::class, 'index'])->name('index');
Route::get('bill', [PurchaseController::class, 'calculateBill'])->name('calculateBill');
Route::post('Purchase/getproductdata',[PurchaseController::class, 'getproductdata'])->name('Purchase.getproductdata');
Route::post('Purchase/generatebilling',[PurchaseController::class, 'generatebilling'])->name('Purchase.generatebilling');
Route::get('viewbill/{id}', [PurchaseController::class, 'viewinvoice'])->name('Purchase.viewinvoice');
Route::get('deletelist/{id}', [PurchaseController::class, 'delete'])->name('Purchase.delete');


// Route::get('testmail', function(){
//     $details=['title'=>'mail from itsolution.com','body'=>'this is for testing email']; \Mail::to('madhaiyanravi13@gmail.com')->send( new \App\Mail\testmail($details)); dd("email is sent.");
// });