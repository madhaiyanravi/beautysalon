
$(document).ready(function () {

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    
    // Add new row
    $('#container').on('click', '.add-row', function() {

        $.ajax({
            type:"POST",
            url: APP_URL+"Purchase/getproductdata",
            success: function(data){
                if(data.status==1)
                {
                    var newRow = '<div class="row col-10 mt-2"> <div class="col-2"></div><div class="col-4">';
                    
                    newRow+='<select class="form-control" name="Product[]" id="Product"><option value="">Select</option>';

                    $.each(data.result,function(index,value){
                        newRow+='<option value="'+value.product_id+'"  >'+value.name+'</option>';
                    });
                    
                    newRow+='</select></div><div class="col-4">' +
                        '<input type="number" class="form-control" name="quantity[]" placeholder="Quantity" min="1"></div><div class="col-1">' +
                        '<button type="button" class="btn btn-danger remove-row">-</button>' +
                        '</div></div>';
                    $('#container').append(newRow);
                        
                }
           }
        }); 
        
    });

    // Remove row
    $('#container').on('click', '.remove-row', function() {
        $(this).closest('.row').remove();
    });
    
    $('.generate-bill').on('click',function(){        
        var fivehundred=$('#fivehundred').val();
        var fifty=$('#fifty').val();
        var twenty=$('#twenty').val();
        var ten=$('#ten').val();
        var five=$('#five').val();
        var two=$('#two').val();
        var one=$('#one').val();
        var cashamount=$('#cashamount').val();

        var formData = $("#product_details").serialize();

        $.ajax({
            type:"POST",
            url: APP_URL+"Purchase/generatebilling",
            data: formData,
            success: function(data){
                if(data.status==1)
                {
                    window.location.href = APP_URL+"viewbill/"+data.result;                        
                }else{
                    alert(data.result);
                }
        }
        }); 

    });

    
});