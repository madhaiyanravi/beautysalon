<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('Products', function (Blueprint $table) {
            $table->integer('product_id')->primary();
            $table->string('name', 45)->nullable();
            $table->integer('available_stocks');
            $table->decimal('price',10,2);
            $table->decimal('tax_percentage',10,2);
            $table->timestamp('updated_at');
            $table->timestamp('created_at');
        });

        Schema::create('purchaselist', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->string('invoice_number', 255)->nullable();
            $table->string('customer_email')->nullable();
            $table->decimal('total_amount',10,2);
            $table->decimal('tax_amount',10,2);
            $table->decimal('Paidamount',10,2);
            $table->timestamp('updated_at');
            $table->timestamp('created_at');
        });

        Schema::create('itemdetails', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->integer('purchaseid');
            $table->integer('product_id');
            $table->decimal('unitprice',10,2);
            $table->integer('quantity');
            $table->decimal('purchaseprice',10,2);
            $table->decimal('taxpercentage',10,2);
            $table->decimal('totalprice',10,2);
            $table->timestamp('updated_at');
            $table->timestamp('created_at');
        });

        Schema::create('Denominations', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->integer('purchaseid');
            $table->integer('fivehundredcount')->nullable();
            $table->integer('fiftycount')->nullable();
            $table->integer('twentycount')->nullable();
            $table->integer('tencount')->nullable();
            $table->integer('fivecount')->nullable();
            $table->integer('twocount')->nullable();
            $table->integer('onecount')->nullable();            
            $table->timestamp('updated_at');
            $table->timestamp('created_at');
        });
    }
    
    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('Products');

        Schema::dropIfExists('purchaselist');

        Schema::dropIfExists('itemdetails');

        Schema::dropIfExists('Denominations');
    }
};
