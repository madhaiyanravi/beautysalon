<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h1>Beauty Salon Booking</h1>
        <form id="booking-form">
        <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="customer_name">Name:</label>
                <input type="text" class="form-control" id="customer_name" name="customer_name" required>
            </div>
            <div class="form-group">
                <label for="customer_mobile">Mobile Number:</label>
                <input type="text" class="form-control" id="customer_mobile" name="customer_mobile" maxlength="10" required>
                <small class="form-text text-muted" style="display:none;">Please enter a 10-digit mobile number.</small>
            </div>
            <div class="form-group">
                <label for="beautician">Beautician:</label>
                <select class="form-control beautician-slot" id="beautician" name="beautician_id" required>
                    <?php $__currentLoopData = $beatician; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($val->id); ?>"><?php echo e($val->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="date">Date:</label>
                <input type="date" class="form-control beautician-slot" id="date" name="date" required>
            </div>
            <div class="form-group">
                <label for="time">Time:</label>
                <select class="form-control" id="time" name="start_time" required>
                </select>
                <span class="holiday d-flex justify-content-center text-danger mt-2"></span>
            </div>
            <a href="<?php echo e(url('/')); ?>" class="side-nav-animation ajaxload" title="billpage"><button type="button" class="btn btn-danger text-black add-row me-md-2">Cancel</button></a>
            <button type="submit" class="btn btn-primary">Book</button>
        </form>
    </div>
    
    <script src="<?php echo e(asset('asset/js/custom.js')); ?>"></script>      

<?php $__env->stopSection(); ?>

<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\beauty-salon\resources\views/booking.blade.php ENDPATH**/ ?>