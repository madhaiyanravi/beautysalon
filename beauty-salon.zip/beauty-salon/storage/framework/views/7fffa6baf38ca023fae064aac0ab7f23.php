<?php $__env->startSection('content'); ?>
    
    <div class="container mt-5">
        <div class="row col-12">
            <div class="col-10">
                <h1>Beauty Salon Booking Calendar</h1>
            </div>
            <div class="col-2">
                <a href="<?php echo e(url('addbook')); ?>" class="side-nav-animation ajaxload" title="billpage"><button type="button" class="btn btn-primary">Book TimeSlot</button></a>
            </div>
        </div>
        
        <div id="calendar"></div>
    </div>
    
    <script src="<?php echo e(asset('asset/js/custom.js')); ?>"></script> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\beauty-salon\resources\views/calendar.blade.php ENDPATH**/ ?>