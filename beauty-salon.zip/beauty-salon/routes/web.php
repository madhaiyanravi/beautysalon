<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BookingController;

Route::get('/', [App\Http\Controllers\BookingController::class, 'calendar']);
Route::get('/addbook', [App\Http\Controllers\BookingController::class, 'index']);
Route::post('/book', [App\Http\Controllers\BookingController::class, 'book']);
Route::get('/available-slots', [App\Http\Controllers\BookingController::class, 'availableSlots']);
Route::get('/fetch-bookings', [App\Http\Controllers\BookingController::class, 'fetchBookings']);


