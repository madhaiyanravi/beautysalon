<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Beautician;
use App\Models\Booking;
use Carbon\Carbon;

class BookingController extends Controller
{
    public function index()
    {
        $data['beatician']= Beautician::all();
        return view('booking',$data);
    }

    public function availableSlots(Request $request)
    {
        $date = $request->input('date');
        $dayOfWeek = Carbon::parse($date)->dayOfWeek;
    
        if ($dayOfWeek == Carbon::FRIDAY) {
            return response()->json([]);
        }
    
        $beauticians = Beautician::all();
        $availableSlots = [];
    
        foreach ($beauticians as $beautician) {
            $bookings = Booking::where('beautician_id', $beautician->id)
                               ->whereDate('start_time', $date)
                               ->get();
    
            $slots = $this->generateSlots($bookings, $date);
            $availableSlots[$beautician->id] = $slots;
        }
    
        return response()->json($availableSlots);
    }
    
    private function generateSlots($bookings, $date)
    {
        $slots = [];
        $start = Carbon::createFromTime(11, 0, 0); 
        $end = Carbon::createFromTime(17, 0, 0);
    
        while ($start->lessThanOrEqualTo($end)) {
            $slot = $start->copy();
            $isAvailable = true;
    
            foreach ($bookings as $booking) {
                if ($start->between($booking->start_time, $booking->end_time)) {
                    $isAvailable = false;
                    break;
                }
            }
    
            if ($isAvailable) {
                $slots[] = $slot->format('g:i A');
            }
    
            $start->addHour();
        }
    
        return $slots;
    }
    

    public function book(Request $request)
    {
        $beauticianId = $request->input('beautician_id');
        $customerName = $request->input('customer_name');
        $customerMobile = $request->input('customer_mobile');
        $startTime = Carbon::parse($request->input('start_time'));
        $endTime = $startTime->copy()->addHour();

        $bookings = Booking::where('beautician_id', $beauticianId)                             ->whereDate('start_time', $startTime)->get();

        if(!empty($bookings)){            
            $availableBeauticians = Beautician::leftJoin('bookings', function ($join) use ($startTime) {
                $join->on('beauticians.id', '=', 'bookings.beautician_id')->whereDate('bookings.start_time', '=', $startTime->toDateString());
            })->whereNull('bookings.id')->select('beauticians.id')->get();
                       
            if ($availableBeauticians->isEmpty()) {
                return response()->json(['status' => 'error', 'message' => 'No available beauticians for selected time slot. Please reschedule the timeslot!']);
            }

            $beautician = $availableBeauticians->first();
            $beauticianId = $beautician->id;
        }

        Booking::create([
            'beautician_id' => $beauticianId,
            'customer_name' => $customerName,
            'customer_mobile' => $customerMobile,
            'start_time' => $startTime,
            'end_time' => $endTime,
        ]);
           

        return response()->json(['status' => 'error','message' => "Booking successful!"]);
    }

    public function calendar()
    {
        return view('calendar');
    }

    public function fetchBookings(Request $request)
    {
        $bookings = Booking::leftJoin('beauticians', 'bookings.beautician_id', '=', 'beauticians.id')->select(['beauticians.name as beautician_name', 'bookings.start_time', 'bookings.end_time', 'bookings.customer_name'])->get();

        return response()->json($bookings);
    }

}
