@extends('header')

@section('content')
    <div class="container mt-5">
        <h1>Beauty Salon Booking</h1>
        <form id="booking-form">
        @csrf
            <div class="form-group">
                <label for="customer_name">Name:</label>
                <input type="text" class="form-control" id="customer_name" name="customer_name" required>
            </div>
            <div class="form-group">
                <label for="customer_mobile">Mobile Number:</label>
                <input type="text" class="form-control" id="customer_mobile" name="customer_mobile" maxlength="10" required>
                <small class="form-text text-muted" style="display:none;">Please enter a 10-digit mobile number.</small>
            </div>
            <div class="form-group">
                <label for="beautician">Beautician:</label>
                <select class="form-control beautician-slot" id="beautician" name="beautician_id" required>
                    @foreach($beatician as $val)
                        <option value="{{ $val->id }}">{{ $val->name }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="date">Date:</label>
                <input type="date" class="form-control beautician-slot" id="date" name="date" required>
            </div>
            <div class="form-group">
                <label for="time">Time:</label>
                <select class="form-control" id="time" name="start_time" required>
                </select>
                <span class="holiday d-flex justify-content-center text-danger mt-2"></span>
            </div>
            <a href="{{url('/')}}" class="side-nav-animation ajaxload" title="billpage"><button type="button" class="btn btn-danger text-black add-row me-md-2">Cancel</button></a>
            <button type="submit" class="btn btn-primary">Book</button>
        </form>
    </div>
    
    <script src="{{asset('asset/js/custom.js')}}"></script>      

@endsection
