@extends('header')

@section('content')
    
    <div class="container mt-5">
        <div class="row col-12">
            <div class="col-10">
                <h1>Beauty Salon Booking Calendar</h1>
            </div>
            <div class="col-2">
                <a href="{{url('addbook')}}" class="side-nav-animation ajaxload" title="billpage"><button type="button" class="btn btn-primary">Book TimeSlot</button></a>
            </div>
        </div>
        
        <div id="calendar"></div>
    </div>
    
    <script src="{{asset('asset/js/custom.js')}}"></script> 
@endsection
