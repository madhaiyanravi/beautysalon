<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class BeauticianSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        \App\Models\Beautician::insert([
            ['name' => 'Ramesh'],
            ['name' => 'Suresh'],
            ['name' => 'Ganesh'],
            ['name' => 'Boopathi'],
            ['name' => 'Santhosh'],
        ]);
    }
}
