$(document).ready(function() {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    var today = new Date().toISOString().split('T')[0];
    $('#date').attr('min', today);

    $('#customer_mobile').on('input', function() {
        var mobileNumber = $(this).val();
        if (/^\d{10}$/.test(mobileNumber)) {
            $(this).removeClass('is-invalid').addClass('is-valid');
            $(".text-muted").hide();
        } else {
            $(this).removeClass('is-valid').addClass('is-invalid');
            $(".text-muted").show();
        }
    });
    
    $('.beautician-slot').change(function() {
        var date = $("#date").val();
        var beauticianId = $('#beautician').val();
        var dayOfWeek = new Date(date).getDay();

        if (dayOfWeek == 5) {
            $('#time').empty();
            $('.holiday').html('<b>All friday holiday!</b>');
            return;
        }else{
            $('.holiday').html("");
        }
        if(beauticianId != "" && date != ""){
            $.ajax({
                url: APP_URL+'available-slots',
                method: 'GET',
                data: { date: date },
                success: function(response) {
                    var timeSelect = $('#time');
                    timeSelect.empty();
    
                    if (response[beauticianId]) {
                        response[beauticianId].forEach(function(slot) {
                            timeSelect.append('<option value="' + date + ' ' + slot + '">' + slot + '</option>');
                        });
                    }
                }
            });
        }
        
    });

    $('#booking-form').submit(function(e) {
        e.preventDefault();

        $.ajax({
            url: APP_URL+'book',
            method: 'POST',
            data: $(this).serialize(),
            success: function(response) {
                if (response.status === 'success') {
                    alert(response.message);
                }else{
                    alert (response.message);
                }
                window.location.href = APP_URL;
            }
        });
    });

    $('#calendar').fullCalendar({
        header: {
            left: 'prev,next today',
            center: 'title',
            right: 'agendaWeek,agendaDay'
        },
        defaultView: 'agendaWeek',
        editable: false,
        events: function(start, end, timezone, callback) {
            $.ajax({
                url: APP_URL+'fetch-bookings',
                dataType: 'json',
                success: function(data) {
                    var events = data.map(function(booking) {
                        return {
                            title: booking.customer_name + ' with Beautician ' + booking.beautician_name,
                            start: booking.start_time,
                            end: booking.end_time
                        };
                    });
                    callback(events);
                }
            });
        },
        minTime: '11:00:00', 
        maxTime: '18:00:00', 
        hiddenDays: [], 
        dayRender: function(date, cell) {
            if (date.day() === 5) {
                cell.css("background-color", "#f0e68c");
                cell.append('<div style="text-align:center; margin-top:5px; color: red;">Holiday</div>');
            }
        }
    });
});